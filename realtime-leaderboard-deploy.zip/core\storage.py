import json
import os
import sqlite3
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime

logger = logging.getLogger("leaderboard.storage")

DEFAULT_SEED_PARTICIPANTS = [
    {
        "id": "p-101",
        "name": "Aria Chen",
        "score": 985.0,
        "category": "Computer Science",
        "avatar": "👩‍💻",
        "created_at": "2026-10-28T10:00:00",
        "updated_at": "2026-10-29T09:45:00",
        "rank": 1,
        "previous_rank": 1,
        "rank_change": 0
    },
    {
        "id": "p-102",
        "name": "Leo Sterling",
        "score": 940.0,
        "category": "AI & Robotics",
        "avatar": "🤖",
        "created_at": "2026-10-28T10:05:00",
        "updated_at": "2026-10-29T10:15:00",
        "rank": 2,
        "previous_rank": 3,
        "rank_change": 1
    },
    {
        "id": "p-103",
        "name": "Maya Patel",
        "score": 915.0,
        "category": "Mathematics",
        "avatar": "📐",
        "created_at": "2026-10-28T10:10:00",
        "updated_at": "2026-10-29T08:30:00",
        "rank": 3,
        "previous_rank": 2,
        "rank_change": -1
    },
    {
        "id": "p-104",
        "name": "Ethan Vance",
        "score": 870.0,
        "category": "Design & UI",
        "avatar": "🎨",
        "created_at": "2026-10-28T10:15:00",
        "updated_at": "2026-10-29T11:00:00",
        "rank": 4,
        "previous_rank": 5,
        "rank_change": 1
    },
    {
        "id": "p-105",
        "name": "Zoe Nakamura",
        "score": 845.0,
        "category": "Computer Science",
        "avatar": "⚡",
        "created_at": "2026-10-28T10:20:00",
        "updated_at": "2026-10-29T07:20:00",
        "rank": 5,
        "previous_rank": 4,
        "rank_change": -1
    },
    {
        "id": "p-106",
        "name": "Lucas Morales",
        "score": 810.0,
        "category": "Data Science",
        "avatar": "📊",
        "created_at": "2026-10-28T10:25:00",
        "updated_at": "2026-10-29T09:10:00",
        "rank": 6,
        "previous_rank": 7,
        "rank_change": 1
    },
    {
        "id": "p-107",
        "name": "Chloe Dubois",
        "score": 790.0,
        "category": "AI & Robotics",
        "avatar": "🚀",
        "created_at": "2026-10-28T10:30:00",
        "updated_at": "2026-10-29T10:50:00",
        "rank": 7,
        "previous_rank": 6,
        "rank_change": -1
    },
    {
        "id": "p-108",
        "name": "Liam O'Connor",
        "score": 750.0,
        "category": "Gaming & VR",
        "avatar": "🎮",
        "created_at": "2026-10-28T10:35:00",
        "updated_at": "2026-10-29T11:20:00",
        "rank": 8,
        "previous_rank": 8,
        "rank_change": 0
    }
]

class StorageManager:
    """
    Unified Storage Manager supporting both JSON file handling and SQLite database.
    Automatically handles Vercel serverless read-only restrictions by saving to /tmp
    or in-memory fallback.
    """
    def __init__(self, mode: str = "json", db_path: Optional[str] = None):
        self.mode = mode.lower()
        self.memory_store: Dict[str, Dict[str, Any]] = {}
        
        # Determine base directory
        is_vercel = os.environ.get("VERCEL") == "1" or os.environ.get("NOW_REGION") is not None
        if is_vercel:
            # On Vercel, use /tmp which is writable
            base_dir = "/tmp"
        else:
            base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data"))
        
        try:
            os.makedirs(base_dir, exist_ok=True)
        except Exception:
            pass

        self.json_file_path = os.path.join(base_dir, "leaderboard.json")
        self.sqlite_file_path = os.path.join(base_dir, "leaderboard.db")

        # Initialize storage
        self._initialize_storage()

    def _initialize_storage(self):
        """Initializes storage file or database with seed data if empty."""
        try:
            if self.mode == "sqlite":
                self._init_sqlite()
            else:
                self._init_json()
        except Exception as e:
            logger.warning(f"File storage initialization notice: {e}. Using in-memory fallback.")
            self._load_seed_to_memory()

    def _init_json(self):
        if not os.path.exists(self.json_file_path):
            self._save_json(DEFAULT_SEED_PARTICIPANTS)
            for p in DEFAULT_SEED_PARTICIPANTS:
                self.memory_store[p["id"]] = dict(p)
        else:
            try:
                with open(self.json_file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    for p in data:
                        self.memory_store[p["id"]] = p
            except Exception:
                self._save_json(DEFAULT_SEED_PARTICIPANTS)
                for p in DEFAULT_SEED_PARTICIPANTS:
                    self.memory_store[p["id"]] = dict(p)

    def _save_json(self, data: List[Dict[str, Any]]):
        try:
            with open(self.json_file_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.warning(f"Could not write to JSON file: {e}")

    def _init_sqlite(self):
        conn = sqlite3.connect(self.sqlite_file_path)
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS participants (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                score REAL NOT NULL,
                category TEXT DEFAULT 'General',
                avatar TEXT DEFAULT '🎯',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                rank INTEGER DEFAULT 0,
                previous_rank INTEGER,
                rank_change INTEGER DEFAULT 0
            )
        """)
        conn.commit()

        cur.execute("SELECT COUNT(*) FROM participants")
        count = cur.fetchone()[0]
        if count == 0:
            for p in DEFAULT_SEED_PARTICIPANTS:
                cur.execute("""
                    INSERT INTO participants (id, name, score, category, avatar, created_at, updated_at, rank, previous_rank, rank_change)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (p["id"], p["name"], p["score"], p["category"], p["avatar"], p["created_at"], p["updated_at"], p["rank"], p["previous_rank"], p["rank_change"]))
            conn.commit()
        conn.close()

    def _load_seed_to_memory(self):
        for p in DEFAULT_SEED_PARTICIPANTS:
            self.memory_store[p["id"]] = dict(p)

    def load_all(self) -> List[Dict[str, Any]]:
        """Loads all participants sorted by score descending."""
        if self.mode == "sqlite":
            try:
                conn = sqlite3.connect(self.sqlite_file_path)
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                cur.execute("SELECT * FROM participants ORDER BY score DESC, updated_at ASC")
                rows = [dict(r) for r in cur.fetchall()]
                conn.close()
                return rows
            except Exception as e:
                logger.warning(f"SQLite load failed: {e}. Falling back to memory.")

        # JSON / Memory mode
        if os.path.exists(self.json_file_path):
            try:
                with open(self.json_file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return data
            except Exception:
                pass
        return list(self.memory_store.values())

    def save_all(self, participants: List[Dict[str, Any]]) -> bool:
        """Saves all participant records to persistence and memory."""
        # Update memory store
        self.memory_store = {p["id"]: p for p in participants}

        # Save to JSON
        self._save_json(participants)

        # Save to SQLite if configured
        if self.mode == "sqlite":
            try:
                conn = sqlite3.connect(self.sqlite_file_path)
                cur = conn.cursor()
                cur.execute("DELETE FROM participants")
                for p in participants:
                    cur.execute("""
                        INSERT INTO participants (id, name, score, category, avatar, created_at, updated_at, rank, previous_rank, rank_change)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (p["id"], p["name"], p["score"], p.get("category", "General"), p.get("avatar", "🎯"),
                          p.get("created_at", ""), p.get("updated_at", ""), p.get("rank", 0),
                          p.get("previous_rank"), p.get("rank_change", 0)))
                conn.commit()
                conn.close()
            except Exception as e:
                logger.warning(f"SQLite save error: {e}")

        return True

    def reset_to_seed(self) -> List[Dict[str, Any]]:
        """Resets the leaderboard to initial demo records."""
        self.memory_store = {p["id"]: dict(p) for p in DEFAULT_SEED_PARTICIPANTS}
        self.save_all(DEFAULT_SEED_PARTICIPANTS)
        return DEFAULT_SEED_PARTICIPANTS
