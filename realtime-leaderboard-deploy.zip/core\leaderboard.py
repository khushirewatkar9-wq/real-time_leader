import statistics
from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid
from .storage import StorageManager
from .models import Participant, TopPerformer, LeaderboardStats, LeaderboardResponse

DEFAULT_AVATARS = ["👩‍💻", "🤖", "🚀", "🎨", "⚡", "📐", "🎮", "📊", "🏆", "🌟", "🔥", "💡"]

class LeaderboardEngine:
    def __init__(self, storage: Optional[StorageManager] = None):
        self.storage = storage or StorageManager(mode="json")
        self.participants: Dict[str, Dict[str, Any]] = {}
        self.recent_events: List[Dict[str, Any]] = []
        self._load_and_refresh()

    def _load_and_refresh(self):
        records = self.storage.load_all()
        self.participants = {p["id"]: p for p in records}
        self._recalculate_rankings()

    def _recalculate_rankings(self):
        """
        Sorts participants in descending order of score.
        Tie breaker: earlier updated_at comes first.
        Updates rank and rank_change.
        """
        if not self.participants:
            return

        # Sort descending by score, ascending by updated_at for tie-break
        sorted_list = sorted(
            self.participants.values(),
            key=lambda x: (-float(x.get("score", 0)), x.get("updated_at", ""))
        )

        for new_rank_idx, p in enumerate(sorted_list, start=1):
            prev_rank = p.get("rank") or new_rank_idx
            p["previous_rank"] = prev_rank
            p["rank"] = new_rank_idx
            # If prev_rank is 5 and new_rank is 2, rank_change is +3 (moved up 3 spots)
            p["rank_change"] = prev_rank - new_rank_idx
            self.participants[p["id"]] = p

        self.storage.save_all(list(self.participants.values()))

    def add_participant(self, name: str, score: float = 0.0, category: str = "General", avatar: Optional[str] = None) -> Dict[str, Any]:
        """Adds a new participant and recalculates rankings."""
        participant_id = f"p-{str(uuid.uuid4())[:6]}"
        now = datetime.utcnow().isoformat()
        
        # Pick avatar if not supplied
        if not avatar or avatar.strip() == "":
            idx = len(self.participants) % len(DEFAULT_AVATARS)
            avatar = DEFAULT_AVATARS[idx]

        new_participant = {
            "id": participant_id,
            "name": name.strip(),
            "score": float(score),
            "category": category.strip() or "General",
            "avatar": avatar,
            "created_at": now,
            "updated_at": now,
            "rank": len(self.participants) + 1,
            "previous_rank": None,
            "rank_change": 0
        }

        self.participants[participant_id] = new_participant
        self._recalculate_rankings()

        # Record activity event
        self._log_event(
            event_type="JOIN",
            participant_id=participant_id,
            name=name,
            message=f"{avatar} {name} joined the competition with {score:.0f} pts!",
            score=score
        )

        return self.participants[participant_id]

    def update_score(self, participant_id: str, score: Optional[float] = None, delta: Optional[float] = None, reason: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Updates participant score either by setting an absolute value or applying a delta.
        Recalculates rankings and tracks rank displacement.
        """
        if participant_id not in self.participants:
            return None

        p = self.participants[participant_id]
        old_score = float(p.get("score", 0))
        old_rank = p.get("rank", 0)

        if score is not None:
            new_score = float(score)
            delta_applied = new_score - old_score
        elif delta is not None:
            delta_applied = float(delta)
            new_score = old_score + delta_applied
        else:
            return p

        # Prevent negative scores if required, or keep raw
        p["score"] = max(0.0, new_score)
        p["updated_at"] = datetime.utcnow().isoformat()
        self.participants[participant_id] = p

        self._recalculate_rankings()
        updated_p = self.participants[participant_id]
        new_rank = updated_p.get("rank", 0)

        # Build celebration or alert message
        symbol = "+" if delta_applied >= 0 else ""
        reason_str = f" ({reason})" if reason else ""
        
        rank_msg = ""
        if new_rank < old_rank:
            if new_rank == 1:
                rank_msg = " 👑 Took #1 spot!"
            else:
                rank_msg = f" 🚀 Climbed to #{new_rank}!"
        elif new_rank > old_rank:
            rank_msg = f" 🔻 Dropped to #{new_rank}"

        self._log_event(
            event_type="SCORE_UPDATE",
            participant_id=participant_id,
            name=updated_p["name"],
            message=f"{updated_p['avatar']} {updated_p['name']} score updated: {symbol}{delta_applied:.0f} pts (Total: {new_score:.0f}){reason_str}{rank_msg}",
            score=new_score,
            delta=delta_applied
        )

        return updated_p

    def delete_participant(self, participant_id: str) -> bool:
        """Deletes a participant from the leaderboard."""
        if participant_id in self.participants:
            name = self.participants[participant_id]["name"]
            del self.participants[participant_id]
            self._recalculate_rankings()
            self._log_event(
                event_type="DELETE",
                participant_id=participant_id,
                name=name,
                message=f"Removed {name} from the leaderboard",
                score=0
            )
            return True
        return False

    def reset_leaderboard(self) -> List[Dict[str, Any]]:
        """Resets the leaderboard to the initial default set."""
        records = self.storage.reset_to_seed()
        self.participants = {p["id"]: p for p in records}
        self._recalculate_rankings()
        self.recent_events.clear()
        self._log_event(
            event_type="RESET",
            participant_id="system",
            name="System",
            message="Leaderboard was reset to standard competition roster",
            score=0
        )
        return self.get_leaderboard()

    def get_top_performers(self, count: int = 3) -> List[Dict[str, Any]]:
        """Returns top performers (Podium: 1st Gold, 2nd Silver, 3rd Bronze)."""
        sorted_list = sorted(
            self.participants.values(),
            key=lambda x: (-float(x.get("score", 0)), x.get("updated_at", ""))
        )
        top = sorted_list[:count]
        badges = ["🥇 Gold", "🥈 Silver", "🥉 Bronze"]

        result = []
        for i, p in enumerate(top):
            badge = badges[i] if i < len(badges) else f"Rank #{i+1}"
            result.append({
                "rank": i + 1,
                "name": p["name"],
                "score": p["score"],
                "avatar": p.get("avatar", "⭐"),
                "category": p.get("category", "General"),
                "badge": badge
            })
        return result

    def get_stats(self) -> Dict[str, Any]:
        """Calculates rich statistical metrics for the leaderboard."""
        if not self.participants:
            return {
                "total_participants": 0,
                "top_score": 0.0,
                "average_score": 0.0,
                "median_score": 0.0,
                "lowest_score": 0.0,
                "categories": [],
                "last_updated": datetime.utcnow().isoformat()
            }

        scores = [float(p.get("score", 0)) for p in self.participants.values()]
        categories = sorted(list(set(p.get("category", "General") for p in self.participants.values())))

        return {
            "total_participants": len(scores),
            "top_score": max(scores),
            "average_score": round(statistics.mean(scores), 1) if scores else 0.0,
            "median_score": round(statistics.median(scores), 1) if scores else 0.0,
            "lowest_score": min(scores),
            "categories": categories,
            "last_updated": datetime.utcnow().isoformat()
        }

    def get_leaderboard(
        self,
        category: Optional[str] = None,
        search: Optional[str] = None,
        limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Returns sorted list of participants with optional filtering."""
        sorted_list = sorted(
            self.participants.values(),
            key=lambda x: (-float(x.get("score", 0)), x.get("updated_at", ""))
        )

        filtered = sorted_list
        if category and category.lower() != "all":
            filtered = [p for p in filtered if p.get("category", "").lower() == category.lower()]

        if search and search.strip():
            q = search.strip().lower()
            filtered = [p for p in filtered if q in p.get("name", "").lower() or q in p.get("category", "").lower()]

        if limit and limit > 0:
            filtered = filtered[:limit]

        return filtered

    def _log_event(self, event_type: str, participant_id: str, name: str, message: str, score: float, delta: float = 0.0):
        event = {
            "id": str(uuid.uuid4())[:8],
            "type": event_type,
            "participant_id": participant_id,
            "name": name,
            "message": message,
            "score": score,
            "delta": delta,
            "timestamp": datetime.utcnow().isoformat()
        }
        self.recent_events.insert(0, event)
        # Keep last 30 events
        if len(self.recent_events) > 30:
            self.recent_events = self.recent_events[:30]

    def get_recent_events(self) -> List[Dict[str, Any]]:
        return self.recent_events
