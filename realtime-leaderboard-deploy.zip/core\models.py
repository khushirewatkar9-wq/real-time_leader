from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid

class ParticipantBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=60, description="Name of the participant")
    score: float = Field(default=0.0, description="Current score")
    category: str = Field(default="General", max_length=40, description="Department, track, or group")
    avatar: Optional[str] = Field(default=None, description="Emoji or avatar icon")

class ParticipantCreate(ParticipantBase):
    pass

class ScoreUpdate(BaseModel):
    score: Optional[float] = Field(default=None, description="Absolute new score value")
    delta: Optional[float] = Field(default=None, description="Increment or decrement value (e.g., +25, -10)")
    reason: Optional[str] = Field(default=None, max_length=100, description="Reason for score adjustment")

class Participant(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    name: str
    score: float
    category: str = "General"
    avatar: str = "🎯"
    created_at: str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    rank: int = 0
    previous_rank: Optional[int] = None
    rank_change: int = 0  # +2 means jumped 2 places, -1 means fell 1 place

class TopPerformer(BaseModel):
    rank: int
    name: str
    score: float
    avatar: str
    category: str
    badge: str

class LeaderboardStats(BaseModel):
    total_participants: int
    top_score: float
    average_score: float
    median_score: float
    lowest_score: float
    categories: List[str]
    last_updated: str

class LeaderboardResponse(BaseModel):
    leaderboard: List[Participant]
    top_performers: List[TopPerformer]
    stats: LeaderboardStats
    total_count: int
