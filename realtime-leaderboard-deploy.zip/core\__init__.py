"""Core package for Real-Time Leaderboard System."""
