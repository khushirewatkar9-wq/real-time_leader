/**
 * PulseBoard: Real-Time Leaderboard System
 * Handles live synchronization, audio feedback, confetti celebrations,
 * podium rendering, and interactive score management.
 */

// Available Avatar Emojis
const AVATARS = ["👩‍💻", "🤖", "🚀", "🎨", "⚡", "📐", "🎮", "📊", "🏆", "🌟", "🔥", "💡", "🧠", "🎯", "🧬", "💎"];

// State
const state = {
  participants: [],
  topPerformers: [],
  stats: {},
  activeCategory: "all",
  searchQuery: "",
  sortBy: "score-desc",
  soundEnabled: true,
  theme: "light",
  isSimulating: false,
  simulationInterval: null,
  syncCountdown: 2,
  syncTimer: null,
  isApiMode: true,
  lastTopOneId: null
};

// Web Audio API Synthesizer (No external mp3 assets required)
let audioCtx = null;
function getAudioContext() {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

function playTone(freq, type = 'sine', duration = 0.15, gainVal = 0.1) {
  if (!state.soundEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);

    gain.gain.setValueAtTime(gainVal, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch (e) {
    console.debug("Audio note skipped:", e);
  }
}

function playScoreChime() {
  playTone(523.25, 'triangle', 0.12, 0.12); // C5
  setTimeout(() => playTone(659.25, 'triangle', 0.16, 0.12), 80); // E5
  setTimeout(() => playTone(783.99, 'triangle', 0.22, 0.15), 160); // G5
}

function playFanfare() {
  playTone(587.33, 'triangle', 0.15, 0.15); // D5
  setTimeout(() => playTone(739.99, 'triangle', 0.15, 0.15), 100); // F#5
  setTimeout(() => playTone(880.00, 'triangle', 0.25, 0.18), 200); // A5
  setTimeout(() => playTone(1174.66, 'sine', 0.4, 0.2), 320); // D6
}

// Fallback Seed Data (used when running purely offline/file:// protocol)
const LOCAL_STORAGE_KEY = "pulseboard_participants_v1";
const FALLBACK_SEED = [
  { id: "p-101", name: "Aria Chen", score: 985.0, category: "Computer Science", avatar: "👩‍💻", rank: 1, previous_rank: 1, rank_change: 0 },
  { id: "p-102", name: "Leo Sterling", score: 940.0, category: "AI & Robotics", avatar: "🤖", rank: 2, previous_rank: 3, rank_change: 1 },
  { id: "p-103", name: "Maya Patel", score: 915.0, category: "Mathematics", avatar: "📐", rank: 3, previous_rank: 2, rank_change: -1 },
  { id: "p-104", name: "Ethan Vance", score: 870.0, category: "Design & UI", avatar: "🎨", rank: 4, previous_rank: 5, rank_change: 1 },
  { id: "p-105", name: "Zoe Nakamura", score: 845.0, category: "Computer Science", avatar: "⚡", rank: 5, previous_rank: 4, rank_change: -1 },
  { id: "p-106", name: "Lucas Morales", score: 810.0, category: "Data Science", avatar: "📊", rank: 6, previous_rank: 7, rank_change: 1 },
  { id: "p-107", name: "Chloe Dubois", score: 790.0, category: "AI & Robotics", avatar: "🚀", rank: 7, previous_rank: 6, rank_change: -1 },
  { id: "p-108", name: "Liam O'Connor", score: 750.0, category: "Gaming & VR", avatar: "🎮", rank: 8, previous_rank: 8, rank_change: 0 }
];

// Initialize on DOM load
document.addEventListener("DOMContentLoaded", () => {
  initIcons();
  buildAvatarPicker();
  setupEventListeners();
  loadData();
  startSyncTimer();
});

function initIcons() {
  if (window.lucide) {
    window.lucide.createIcons();
  }
}

// Event Listeners Setup
function setupEventListeners() {
  // Theme Toggle
  const themeBtn = document.getElementById("themeToggleBtn");
  themeBtn.addEventListener("click", toggleTheme);

  // Audio Toggle
  const audioBtn = document.getElementById("audioToggleBtn");
  audioBtn.addEventListener("click", toggleAudio);

  // Search
  const searchInput = document.getElementById("searchInput");
  searchInput.addEventListener("input", (e) => {
    state.searchQuery = e.target.value.trim().toLowerCase();
    document.getElementById("clearSearchBtn").style.display = state.searchQuery ? "block" : "none";
    renderLeaderboard();
  });

  document.getElementById("clearSearchBtn").addEventListener("click", () => {
    searchInput.value = "";
    state.searchQuery = "";
    document.getElementById("clearSearchBtn").style.display = "none";
    renderLeaderboard();
  });

  // Sort
  document.getElementById("sortSelect").addEventListener("change", (e) => {
    state.sortBy = e.target.value;
    renderLeaderboard();
  });

  // Manual Refresh
  document.getElementById("refreshBtn").addEventListener("click", () => {
    loadData(true);
  });

  // Reset Leaderboard
  document.getElementById("resetLeaderboardBtn").addEventListener("click", handleResetLeaderboard);

  // Live Simulator Button
  document.getElementById("simLiveBtn").addEventListener("click", toggleSimulation);

  // Add Participant Modal
  document.getElementById("openAddModalBtn").addEventListener("click", () => openModal("addModal"));
  document.getElementById("closeAddModalBtn").addEventListener("click", () => closeModal("addModal"));
  document.getElementById("cancelAddBtn").addEventListener("click", () => closeModal("addModal"));
  document.getElementById("addParticipantForm").addEventListener("submit", handleAddParticipantSubmit);

  // Score Modal
  document.getElementById("closeScoreModalBtn").addEventListener("click", () => closeModal("scoreModal"));
  document.getElementById("cancelScoreBtn").addEventListener("click", () => closeModal("scoreModal"));
  document.getElementById("saveScoreBtn").addEventListener("click", handleSaveScore);

  // Quick Delta buttons inside Score Modal
  document.querySelectorAll(".delta-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const delta = parseFloat(btn.dataset.delta);
      const participantId = document.getElementById("editParticipantId").value;
      submitScoreUpdate(participantId, { delta });
      closeModal("scoreModal");
    });
  });

  // Reset filters button in empty state
  document.getElementById("resetFilterBtn").addEventListener("click", () => {
    state.searchQuery = "";
    state.activeCategory = "all";
    document.getElementById("searchInput").value = "";
    document.querySelectorAll(".cat-pill").forEach(p => p.classList.remove("active"));
    const allPill = document.querySelector('.cat-pill[data-category="all"]');
    if (allPill) allPill.classList.add("active");
    renderLeaderboard();
  });
}

// Build Avatar Picker Grid
function buildAvatarPicker() {
  const container = document.getElementById("avatarPicker");
  container.innerHTML = "";
  AVATARS.forEach((emoji, index) => {
    const div = document.createElement("div");
    div.className = `avatar-option ${index === 0 ? 'selected' : ''}`;
    div.textContent = emoji;
    div.addEventListener("click", () => {
      document.querySelectorAll(".avatar-option").forEach(el => el.classList.remove("selected"));
      div.classList.add("selected");
      document.getElementById("selectedAvatar").value = emoji;
    });
    container.appendChild(div);
  });
}

// Fetch Leaderboard from API or LocalStorage
async function loadData(showToastNotice = false) {
  try {
    const res = await fetch("/api/leaderboard", { cache: "no-store" });
    if (!res.ok) throw new Error("API not reachable");

    const data = await res.json();
    state.isApiMode = true;
    state.participants = data.leaderboard || [];
    state.topPerformers = data.top_performers || [];
    state.stats = data.stats || {};

    if (data.recent_events && data.recent_events.length > 0) {
      updateTicker(data.recent_events[0].message);
    }

    processRankDisplacement();
    renderAll();
    if (showToastNotice) showToast("Leaderboard synced with live engine", "success");
  } catch (err) {
    // Offline / Standalone static file fallback
    state.isApiMode = false;
    loadLocalFallback();
    if (showToastNotice) showToast("Offline mode: changes stored locally", "info");
  }
}

function loadLocalFallback() {
  const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
  if (stored) {
    try {
      state.participants = JSON.parse(stored);
    } catch (e) {
      state.participants = [...FALLBACK_SEED];
    }
  } else {
    state.participants = [...FALLBACK_SEED];
    saveLocalFallback();
  }
  recalcLocalRankings();
  renderAll();
}

function saveLocalFallback() {
  localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(state.participants));
}

function recalcLocalRankings() {
  state.participants.sort((a, b) => b.score - a.score);
  state.participants.forEach((p, idx) => {
    const prev = p.rank || (idx + 1);
    p.previous_rank = prev;
    p.rank = idx + 1;
    p.rank_change = prev - (idx + 1);
  });

  const scores = state.participants.map(p => p.score);
  const categories = [...new Set(state.participants.map(p => p.category || "General"))];
  const avg = scores.length ? (scores.reduce((a, b) => a + b, 0) / scores.length).toFixed(1) : 0;

  state.stats = {
    total_participants: state.participants.length,
    top_score: scores.length ? Math.max(...scores) : 0,
    average_score: avg,
    categories: categories
  };

  state.topPerformers = state.participants.slice(0, 3).map((p, i) => ({
    rank: i + 1,
    name: p.name,
    score: p.score,
    avatar: p.avatar,
    category: p.category,
    badge: ["🥇 Gold", "🥈 Silver", "🥉 Bronze"][i] || `#${i+1}`
  }));

  processRankDisplacement();
}

function processRankDisplacement() {
  if (state.participants.length > 0) {
    const topOne = state.participants[0];
    if (state.lastTopOneId && state.lastTopOneId !== topOne.id) {
      // #1 spot changed!
      triggerCelebration(topOne.name);
    }
    state.lastTopOneId = topOne.id;
  }
}

// Render everything
function renderAll() {
  renderStats();
  renderPodium();
  renderCategories();
  renderLeaderboard();
  initIcons();
}

// Render Stats Cards
function renderStats() {
  const stats = state.stats;
  document.getElementById("statParticipants").textContent = stats.total_participants ?? state.participants.length;
  document.getElementById("statTopScore").textContent = stats.top_score != null ? `${stats.top_score.toLocaleString()}` : "--";
  document.getElementById("statAvgScore").textContent = stats.average_score != null ? `${stats.average_score}` : "--";

  const categories = stats.categories || [];
  document.getElementById("statCategories").textContent = categories.length || 1;

  if (state.participants.length > 0) {
    document.getElementById("statTopName").textContent = `Held by ${state.participants[0].name}`;
  }
}

// Render 3D Podium for Top 3
function renderPodium() {
  const container = document.getElementById("podiumContainer");
  const top = state.topPerformers.length ? state.topPerformers : state.participants.slice(0, 3);

  if (!top || top.length === 0) {
    container.innerHTML = '<div class="podium-skeleton">Add contenders to build the podium</div>';
    return;
  }

  const p1 = top[0];
  const p2 = top[1];
  const p3 = top[2];

  let html = '';

  // Rank 2 (Left)
  if (p2) {
    html += `
      <div class="podium-slot rank-2">
        <div class="podium-avatar-wrap">
          <div class="podium-avatar">${p2.avatar}</div>
          <span class="podium-badge-icon">🥈</span>
        </div>
        <div class="podium-name" title="${p2.name}">${p2.name}</div>
        <div class="podium-cat">${p2.category}</div>
        <div class="podium-score-pill">${p2.score.toLocaleString()} pts</div>
        <div class="podium-block">
          <span>2</span>
          <span class="podium-block-sub">Silver</span>
        </div>
      </div>
    `;
  }

  // Rank 1 (Center)
  if (p1) {
    html += `
      <div class="podium-slot rank-1">
        <div class="podium-avatar-wrap">
          <span class="podium-crown">👑</span>
          <div class="podium-avatar">${p1.avatar}</div>
          <span class="podium-badge-icon">🥇</span>
        </div>
        <div class="podium-name" title="${p1.name}">${p1.name}</div>
        <div class="podium-cat">${p1.category}</div>
        <div class="podium-score-pill">${p1.score.toLocaleString()} pts</div>
        <div class="podium-block">
          <span>1</span>
          <span class="podium-block-sub">Champion</span>
        </div>
      </div>
    `;
  }

  // Rank 3 (Right)
  if (p3) {
    html += `
      <div class="podium-slot rank-3">
        <div class="podium-avatar-wrap">
          <div class="podium-avatar">${p3.avatar}</div>
          <span class="podium-badge-icon">🥉</span>
        </div>
        <div class="podium-name" title="${p3.name}">${p3.name}</div>
        <div class="podium-cat">${p3.category}</div>
        <div class="podium-score-pill">${p3.score.toLocaleString()} pts</div>
        <div class="podium-block">
          <span>3</span>
          <span class="podium-block-sub">Bronze</span>
        </div>
      </div>
    `;
  }

  container.innerHTML = html;
}

// Render Category Filter Pills
function renderCategories() {
  const container = document.getElementById("categoryTabs");
  const categories = state.stats.categories || [...new Set(state.participants.map(p => p.category || "General"))];

  let html = `<button class="cat-pill ${state.activeCategory === 'all' ? 'active' : ''}" data-category="all">All Tracks</button>`;

  categories.forEach(cat => {
    const isActive = state.activeCategory.toLowerCase() === cat.toLowerCase();
    html += `<button class="cat-pill ${isActive ? 'active' : ''}" data-category="${cat}">${cat}</button>`;
  });

  container.innerHTML = html;

  // Add click events
  container.querySelectorAll(".cat-pill").forEach(btn => {
    btn.addEventListener("click", () => {
      container.querySelectorAll(".cat-pill").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      state.activeCategory = btn.dataset.category;
      renderLeaderboard();
    });
  });
}

// Render Leaderboard Rows
function renderLeaderboard() {
  const container = document.getElementById("leaderboardList");
  const emptyState = document.getElementById("emptyState");

  let list = [...state.participants];

  // Filter Category
  if (state.activeCategory && state.activeCategory.toLowerCase() !== "all") {
    list = list.filter(p => (p.category || "").toLowerCase() === state.activeCategory.toLowerCase());
  }

  // Filter Search
  if (state.searchQuery) {
    list = list.filter(p =>
      p.name.toLowerCase().includes(state.searchQuery) ||
      (p.category && p.category.toLowerCase().includes(state.searchQuery))
    );
  }

  // Sort
  if (state.sortBy === "score-desc") {
    list.sort((a, b) => b.score - a.score);
  } else if (state.sortBy === "score-asc") {
    list.sort((a, b) => a.score - b.score);
  } else if (state.sortBy === "name-asc") {
    list.sort((a, b) => a.name.localeCompare(b.name));
  } else if (state.sortBy === "rank-change") {
    list.sort((a, b) => (b.rank_change || 0) - (a.rank_change || 0));
  }

  if (list.length === 0) {
    container.innerHTML = "";
    emptyState.style.display = "flex";
    return;
  }

  emptyState.style.display = "none";

  const maxScore = state.participants.length ? Math.max(...state.participants.map(p => p.score), 100) : 100;

  let html = "";
  list.forEach(p => {
    // Rank badge class
    let rankBadgeClass = "rank-normal-badge";
    if (p.rank === 1) rankBadgeClass = "rank-1-badge";
    else if (p.rank === 2) rankBadgeClass = "rank-2-badge";
    else if (p.rank === 3) rankBadgeClass = "rank-3-badge";

    // Trend Indicator
    let trendHtml = '<span class="trend-pill trend-same">➖ 0</span>';
    if (p.rank_change > 0) {
      trendHtml = `<span class="trend-pill trend-up">▲ +${p.rank_change}</span>`;
    } else if (p.rank_change < 0) {
      trendHtml = `<span class="trend-pill trend-down">▼ ${p.rank_change}</span>`;
    }

    const progressPct = Math.min(100, Math.max(5, (p.score / maxScore) * 100));

    html += `
      <div class="leaderboard-row ${p.rank <= 3 ? 'highlight-top' : ''}" data-id="${p.id}">
        <div class="col-rank">
          <div class="rank-badge ${rankBadgeClass}">#${p.rank}</div>
        </div>

        <div class="col-participant">
          <div class="participant-avatar">${p.avatar || '🎯'}</div>
          <div class="participant-info">
            <span class="participant-name">${escapeHtml(p.name)}</span>
            <span class="participant-id">${p.id}</span>
          </div>
        </div>

        <div class="col-track">
          <span class="track-tag">${escapeHtml(p.category || 'General')}</span>
        </div>

        <div class="col-score">
          <span class="score-num">${p.score.toLocaleString()} <span style="font-size:0.75rem; color:var(--text-muted); font-weight:600;">pts</span></span>
          <div class="score-progress-bar">
            <div class="score-progress-fill" style="width: ${progressPct}%;"></div>
          </div>
        </div>

        <div class="col-trend">
          ${trendHtml}
        </div>

        <div class="col-actions">
          <button class="mini-score-btn" onclick="quickAddPoints('${p.id}', 10)">+10</button>
          <button class="mini-score-btn" onclick="quickAddPoints('${p.id}', 25)">+25</button>
          <button class="action-icon-btn" onclick="openScoreModal('${p.id}')" title="Adjust Score">
            <i data-lucide="sliders"></i>
          </button>
          <button class="action-icon-btn delete-btn" onclick="handleDeleteParticipant('${p.id}')" title="Delete Participant">
            <i data-lucide="trash-2"></i>
          </button>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
  initIcons();
}

// Quick Inline Points Increment
window.quickAddPoints = function(participantId, delta) {
  submitScoreUpdate(participantId, { delta });
};

// Open Adjust Score Modal
window.openScoreModal = function(participantId) {
  const p = state.participants.find(item => item.id === participantId);
  if (!p) return;

  document.getElementById("editParticipantId").value = p.id;
  document.getElementById("scoreModalTitle").textContent = `Adjust Score: ${p.name}`;
  document.getElementById("currentScoreDisplay").textContent = `${p.score.toLocaleString()} pts`;
  document.getElementById("customDeltaInput").value = "";
  document.getElementById("absoluteScoreInput").value = "";
  document.getElementById("scoreReasonInput").value = "";

  openModal("scoreModal");
};

// Save Score from Modal Inputs
function handleSaveScore() {
  const participantId = document.getElementById("editParticipantId").value;
  const deltaVal = document.getElementById("customDeltaInput").value;
  const absVal = document.getElementById("absoluteScoreInput").value;
  const reason = document.getElementById("scoreReasonInput").value.trim();

  const payload = {};
  if (absVal !== "") {
    payload.score = parseFloat(absVal);
  } else if (deltaVal !== "") {
    payload.delta = parseFloat(deltaVal);
  } else {
    showToast("Please enter an adjustment (+/-) or absolute score", "error");
    return;
  }

  if (reason) payload.reason = reason;

  submitScoreUpdate(participantId, payload);
  closeModal("scoreModal");
}

// Submit Score Update to Backend or Local Storage
async function submitScoreUpdate(participantId, payload) {
  playScoreChime();

  if (state.isApiMode) {
    try {
      const res = await fetch(`/api/participants/${participantId}/score`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error("Update failed");
      const data = await res.json();
      showToast(data.message || "Score updated!", "success");
      loadData();
      return;
    } catch (e) {
      console.warn("API error, saving locally:", e);
    }
  }

  // Local fallback execution
  const p = state.participants.find(item => item.id === participantId);
  if (p) {
    const oldScore = p.score;
    if (payload.score !== undefined) {
      p.score = Math.max(0, payload.score);
    } else if (payload.delta !== undefined) {
      p.score = Math.max(0, p.score + payload.delta);
    }
    const diff = p.score - oldScore;
    const sign = diff >= 0 ? "+" : "";
    updateTicker(`${p.avatar} ${p.name} updated: ${sign}${diff} pts (Total: ${p.score})`);
    saveLocalFallback();
    recalcLocalRankings();
    renderAll();
    showToast(`Updated ${p.name}'s score to ${p.score}`, "success");
  }
}

// Add Participant
async function handleAddParticipantSubmit(e) {
  e.preventDefault();
  const name = document.getElementById("newPartName").value.trim();
  const score = parseFloat(document.getElementById("newPartScore").value) || 0;
  const category = document.getElementById("newPartCategory").value.trim() || "General";
  const avatar = document.getElementById("selectedAvatar").value || "👩‍💻";

  if (!name) {
    showToast("Please enter participant name", "error");
    return;
  }

  if (state.isApiMode) {
    try {
      const res = await fetch("/api/participants", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, score, category, avatar })
      });
      if (!res.ok) throw new Error("Could not add participant");
      const data = await res.json();
      showToast(data.message || `Added ${name}!`, "success");
      closeModal("addModal");
      document.getElementById("addParticipantForm").reset();
      loadData();
      playScoreChime();
      return;
    } catch (err) {
      console.warn("API add failed, saving locally:", err);
    }
  }

  // Local storage mode
  const newPart = {
    id: `p-${Math.floor(100 + Math.random() * 900)}`,
    name,
    score,
    category,
    avatar,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  state.participants.push(newPart);
  saveLocalFallback();
  recalcLocalRankings();
  renderAll();
  closeModal("addModal");
  document.getElementById("addParticipantForm").reset();
  showToast(`Registered ${name} to leaderboard!`, "success");
  playScoreChime();
}

// Delete Participant
window.handleDeleteParticipant = async function(participantId) {
  const p = state.participants.find(item => item.id === participantId);
  const name = p ? p.name : "Participant";

  if (!confirm(`Are you sure you want to remove ${name} from the competition?`)) {
    return;
  }

  if (state.isApiMode) {
    try {
      const res = await fetch(`/api/participants/${participantId}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Delete failed");
      showToast(`Removed ${name}`, "info");
      loadData();
      return;
    } catch (e) {
      console.warn("API delete failed, removing locally:", e);
    }
  }

  state.participants = state.participants.filter(item => item.id !== participantId);
  saveLocalFallback();
  recalcLocalRankings();
  renderAll();
  showToast(`Removed ${name}`, "info");
};

// Reset Leaderboard
async function handleResetLeaderboard() {
  if (!confirm("Reset leaderboard back to starting tournament roster?")) return;

  if (state.isApiMode) {
    try {
      const res = await fetch("/api/reset", { method: "POST" });
      if (res.ok) {
        showToast("Leaderboard reset to default competition state", "success");
        loadData();
        return;
      }
    } catch (e) {
      console.warn("API reset failed:", e);
    }
  }

  state.participants = [...FALLBACK_SEED];
  saveLocalFallback();
  recalcLocalRankings();
  renderAll();
  showToast("Leaderboard reset to default roster", "success");
}

// Real-Time Simulator Toggle
function toggleSimulation() {
  const btn = document.getElementById("simLiveBtn");
  state.isSimulating = !state.isSimulating;

  if (state.isSimulating) {
    btn.classList.add("btn-primary");
    btn.classList.remove("btn-secondary");
    btn.querySelector("span").textContent = "Sim Running ⚡";
    showToast("Live simulation bot engaged! Watch live score updates.", "info");

    state.simulationInterval = setInterval(async () => {
      if (state.isApiMode) {
        try {
          const res = await fetch("/api/simulate", { method: "POST" });
          if (res.ok) {
            const data = await res.json();
            loadData();
            return;
          }
        } catch (e) {}
      }

      // Local simulation
      if (state.participants.length > 0) {
        const randomIndex = Math.floor(Math.random() * state.participants.length);
        const p = state.participants[randomIndex];
        const boost = [15, 25, 35, 50, 75][Math.floor(Math.random() * 5)];
        p.score += boost;
        updateTicker(`⚡ ${p.avatar} ${p.name} earned +${boost} pts!`);
        saveLocalFallback();
        recalcLocalRankings();
        renderAll();
        playTone(600 + Math.random() * 200, 'sine', 0.1, 0.08);
      }
    }, 2800);
  } else {
    clearInterval(state.simulationInterval);
    btn.classList.remove("btn-primary");
    btn.classList.add("btn-secondary");
    btn.querySelector("span").textContent = "Live Sim";
    showToast("Live simulation paused", "info");
  }
}

// Periodic Background Sync Timer
function startSyncTimer() {
  const counterEl = document.getElementById("syncCounter");
  let timeLeft = 2;

  setInterval(() => {
    timeLeft -= 1;
    if (timeLeft <= 0) {
      timeLeft = 2;
      loadData();
    }
    if (counterEl) counterEl.textContent = `${timeLeft}s`;
  }, 1000);
}

// Celebration / Confetti Trigger
function triggerCelebration(winnerName) {
  playFanfare();
  showToast(`🎉 👑 ${winnerName} has taken the #1 Champion Rank!`, "success");

  if (window.confetti) {
    // Pink and Light Blue Confetti Colors!
    const colors = ['#ec4899', '#f472b6', '#38bdf8', '#0ea5e9', '#fbbf24', '#ffffff'];
    window.confetti({
      particleCount: 120,
      spread: 80,
      origin: { y: 0.6 },
      colors: colors
    });

    setTimeout(() => {
      window.confetti({
        particleCount: 60,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: colors
      });
      window.confetti({
        particleCount: 60,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: colors
      });
    }, 200);
  }
}

// UI Ticker Update
function updateTicker(message) {
  const el = document.getElementById("tickerText");
  if (el) {
    el.textContent = message;
    el.style.animation = 'none';
    el.offsetHeight; // trigger reflow
    el.style.animation = 'tickerFade 0.4s ease-in-out';
  }
}

// Toast Notifications
function showToast(message, type = "info") {
  const container = document.getElementById("toastContainer");
  const toast = document.createElement("div");
  toast.className = "toast";

  let icon = "info";
  if (type === "success") icon = "check-circle";
  if (type === "error") icon = "alert-circle";

  toast.innerHTML = `
    <i data-lucide="${icon}" style="color: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#ec4899'};"></i>
    <span>${escapeHtml(message)}</span>
  `;

  container.appendChild(toast);
  initIcons();

  setTimeout(() => {
    toast.classList.add("toast-leave");
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

// Theme Toggle
function toggleTheme() {
  const body = document.body;
  const isLight = body.classList.contains("theme-light");
  const icon = document.getElementById("themeIcon");

  if (isLight) {
    body.classList.remove("theme-light");
    body.classList.add("theme-dark");
    icon.setAttribute("data-lucide", "sun");
    state.theme = "dark";
  } else {
    body.classList.remove("theme-dark");
    body.classList.add("theme-light");
    icon.setAttribute("data-lucide", "moon");
    state.theme = "light";
  }
  initIcons();
}

// Audio Toggle
function toggleAudio() {
  state.soundEnabled = !state.soundEnabled;
  const icon = document.getElementById("audioIcon");
  if (state.soundEnabled) {
    icon.setAttribute("data-lucide", "volume-2");
    showToast("Audio chimes enabled 🔔", "info");
    playTone(659.25, 'triangle', 0.1, 0.1);
  } else {
    icon.setAttribute("data-lucide", "volume-x");
    showToast("Audio chimes muted", "info");
  }
  initIcons();
}

// Modal Helpers
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.add("active");
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.remove("active");
}

// Utility: escape HTML to prevent XSS
function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
