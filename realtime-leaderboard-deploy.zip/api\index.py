import os
import sys
from typing import Optional
from fastapi import FastAPI, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles

# Add parent directory to sys.path so core modules can be imported seamlessly
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.abspath(os.path.join(current_dir, ".."))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from core.leaderboard import LeaderboardEngine
from core.models import ParticipantCreate, ScoreUpdate

app = FastAPI(
    title="Real-Time Leaderboard API",
    description="High-performance real-time leaderboard engine with instant sorting and rank tracking",
    version="1.0.0"
)

# Enable CORS for all origins (vital for Vercel and multi-origin frontends)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize engine instance
engine = LeaderboardEngine()

# Mount public directory for static assets if it exists
public_path = os.path.join(parent_dir, "public")
if os.path.exists(public_path):
    app.mount("/static", StaticFiles(directory=public_path), name="static")

@app.get("/", response_class=HTMLResponse)
async def serve_home():
    """Serves the main Leaderboard web application."""
    index_file = os.path.join(public_path, "index.html")
    if os.path.exists(index_file):
        with open(index_file, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse("<h1>Real-Time Leaderboard System</h1><p>Visit /docs for API documentation.</p>")

@app.get("/style.css")
async def serve_css():
    """Direct root route for stylesheet."""
    css_file = os.path.join(public_path, "style.css")
    if os.path.exists(css_file):
        return FileResponse(css_file, media_type="text/css")
    raise HTTPException(status_code=404, detail="CSS file not found")

@app.get("/app.js")
async def serve_js():
    """Direct root route for client script."""
    js_file = os.path.join(public_path, "app.js")
    if os.path.exists(js_file):
        return FileResponse(js_file, media_type="application/javascript")
    raise HTTPException(status_code=404, detail="JavaScript file not found")

@app.get("/api/leaderboard")
async def get_leaderboard(
    category: Optional[str] = Query(None, description="Filter by category (e.g. 'Computer Science')"),
    search: Optional[str] = Query(None, description="Search participant by name or category"),
    limit: Optional[int] = Query(None, description="Limit number of participants returned")
):
    """
    Returns full sorted leaderboard, top 3 podium performers, overall statistics,
    and recent activity events.
    """
    leaderboard = engine.get_leaderboard(category=category, search=search, limit=limit)
    top_performers = engine.get_top_performers(count=3)
    stats = engine.get_stats()
    events = engine.get_recent_events()

    return {
        "success": True,
        "total_count": len(leaderboard),
        "leaderboard": leaderboard,
        "top_performers": top_performers,
        "stats": stats,
        "recent_events": events[:10]
    }

@app.post("/api/participants", status_code=status.HTTP_201_CREATED)
async def add_participant(payload: ParticipantCreate):
    """
    Registers a new participant into the competition.
    Instantly recalculates ranks.
    """
    if not payload.name or not payload.name.strip():
        raise HTTPException(status_code=400, detail="Participant name cannot be empty")

    new_p = engine.add_participant(
        name=payload.name,
        score=payload.score,
        category=payload.category,
        avatar=payload.avatar
    )
    return {
        "success": True,
        "message": f"Added {new_p['name']} with initial score {new_p['score']}",
        "participant": new_p
    }

@app.patch("/api/participants/{participant_id}/score")
async def update_score(participant_id: str, payload: ScoreUpdate):
    """
    Updates a participant's score either by absolute score or relative delta (+10, -5).
    Instantly sorts and tracks rank changes.
    """
    updated_p = engine.update_score(
        participant_id=participant_id,
        score=payload.score,
        delta=payload.delta,
        reason=payload.reason
    )
    if not updated_p:
        raise HTTPException(status_code=404, detail="Participant not found")

    return {
        "success": True,
        "message": f"Updated score for {updated_p['name']}",
        "participant": updated_p
    }

@app.delete("/api/participants/{participant_id}")
async def delete_participant(participant_id: str):
    """Deletes a participant and updates rankings."""
    success = engine.delete_participant(participant_id)
    if not success:
        raise HTTPException(status_code=404, detail="Participant not found")
    return {
        "success": True,
        "message": "Participant removed successfully"
    }

@app.post("/api/reset")
async def reset_leaderboard():
    """Resets leaderboard to initial tournament roster."""
    reset_data = engine.reset_leaderboard()
    return {
        "success": True,
        "message": "Leaderboard reset to default competition state",
        "leaderboard": reset_data
    }

@app.get("/api/stats")
async def get_stats():
    """Returns aggregated score analytics and metrics."""
    return {
        "success": True,
        "stats": engine.get_stats(),
        "top_performers": engine.get_top_performers(count=3)
    }

@app.get("/api/events")
async def get_events():
    """Returns live feed of score adjustments and rankings changes."""
    return {
        "success": True,
        "events": engine.get_recent_events()
    }

@app.post("/api/simulate")
async def simulate_live_event():
    """
    Simulates a live competition event (a random participant gains points).
    Great for showcasing real-time leaderboard capabilities on demo day.
    """
    import random
    if not engine.participants:
        return {"success": False, "message": "No participants to simulate"}

    chosen_id = random.choice(list(engine.participants.keys()))
    delta = random.choice([15, 25, 40, 50, 75, 100])
    reasons = [
        "Solved Algorithm Challenge",
        "Completed Robotics Sprint",
        "Perfect Score in Math Olympiad",
        "Won Speed Coding Round",
        "Submitted Design Prototype",
        "Bonus Quiz Answer"
    ]
    reason = random.choice(reasons)
    updated_p = engine.update_score(participant_id=chosen_id, delta=delta, reason=reason)
    return {
        "success": True,
        "message": f"Simulated score bump for {updated_p['name']}",
        "participant": updated_p
    }

# Health check
@app.get("/api/health")
async def health():
    return {"status": "ok", "app": "Real-Time Leaderboard System", "theme": "Pink & Light Blue"}
